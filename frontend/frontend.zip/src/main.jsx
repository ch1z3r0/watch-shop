import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';
import './fontawesome.js';

import { ASSETS } from './utils/assets.js';
import { AuthProvider } from './auth/AuthProvider.jsx';
import { FavouritesProvider } from './context/FavouritesContext.jsx';
// ---- inject fonts globally from ASSETS ----
(function injectSamsungFonts() {
	if (document.querySelector('style[data-fonts="samsung"]')) return; // avoid duplicates
	// console.log(ASSETS.samsungSharpSansBold);

	const css = `
		@font-face{
		font-family:"SamsungOne";
		src: url("${ASSETS.samsungOne}") format("truetype");
		font-weight:400;
		font-style:normal;
		font-display:swap;
		}
		@font-face{
		font-family:"SamsungOne700";
		src: url("${ASSETS.samsungOne700}") format("truetype");
		font-weight:700;
		font-style:normal;
		font-display:swap;
		}
		@font-face{
			font-family:"SamsungSharpSans";
			src: url("${ASSETS.samsungSharpSansBold}") format("truetype");
		font-weight:700;
		font-style:normal;
		font-display:swap;
	}
	`.trim();

	const style = document.createElement('style');
	style.setAttribute('data-fonts', 'samsung');
	style.textContent = css;
	document.head.appendChild(style);
})();

createRoot(document.getElementById('root')).render(
	<StrictMode>
		<AuthProvider>
			<FavouritesProvider>
				<App />
			</FavouritesProvider>
		</AuthProvider>
	</StrictMode>,
);
